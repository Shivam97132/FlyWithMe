import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { BookingService } from '../booking.service';
import { Flight } from '../flight';
import { Booking } from '../booking';
import { FormGroup, FormControl, Validators} from '@angular/forms'; 
import { User } from '../user';
import emailjs,{ EmailJSResponseStatus } from '@emailjs/browser';


@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  users:User[]=[];
  paymentData = {
    cardNumber: '',
    cardHolder: '',
    expiryDate: '',
    cvv: '',
  };
  today = new Date().toISOString().split('T')[0];


  userData: any;
  flightData: any;

  form!: FormGroup;
  flight!: Flight;
  flights: Flight[] = [];
  flag:boolean = false;
  booking!: Booking;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private bookingService: BookingService
  ) {}

  ngOnInit() {
    // Retrieve the user data and flight data from route parameters
    this.route.queryParams.subscribe(params => {
      this.userData = JSON.parse(params['userData']);
      this.flightData = JSON.parse(params['flightData']);
    });
  }

  submitPayment() {
    
    // Handle payment submission logic here
    console.log('Payment data:', this.paymentData);
    // You would typically send this data to a server for processing

    const paymentSuccessful = true;

    if (paymentSuccessful) {
      // Generate a ticket (you can implement this logic)
      // You can access the user data and flight data here
      console.log('User data:', this.userData);
      console.log('Flight data:', this.flightData);

      // Redirect to another page or perform any other action
      this.bookingService.create(this.userData).subscribe((res:any) => {
        alert("Your booking has been successfully created.");
        console.log('Booking added successfully!');
        this.booking = res;
        this.router.navigateByUrl('ticket/'+this.booking.bookingId);
      })
      // Navigate to the ticket page, for example
      this.router.navigate(['/ticket']);
      this.sendEmail;
    } else {
      alert('Payment failed. Please try again.');
      }
  }
  sendEmail(users: User) {
    emailjs.send("service_nutsxgp", "template_jfxgmph", {
      reply_to: users.email
    }, "S4FF8BDWk4YBbSuqO")
    .then(function(response) {
        console.log("Email sent successfully:", response);
      }, function(error) {
        console.error("Email sending error:", error);
      });
  }
}