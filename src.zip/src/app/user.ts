export interface User {
    userId: number;
    username: string;
    email: string;
    age: number;
    password: string;
    confirmPassword: string;
    userType: string;
}